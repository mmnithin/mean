function myDateTime(){
    return Date();
}

module.exports.myDateTime=myDateTime;

