var logger =require('./logger1.js')
logger("Hello");