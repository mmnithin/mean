const files =require("fs")

const file=files.readdirSync('./');
console.log(file);