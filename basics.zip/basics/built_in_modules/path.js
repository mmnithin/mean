const path =require("path");
var obj=path.parse(__filename);
console.log(obj);