const read=require('fs')
var readFile1=read.readFileSync("test.txt",'utf8');
console.log(readFile1);