function print(message){
    console.log(message);

}
module.exports=print;
