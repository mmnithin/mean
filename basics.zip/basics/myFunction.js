function sayHai(name){
    console.log("Hai"+"  "+name);
}
sayHai('Nithin');
