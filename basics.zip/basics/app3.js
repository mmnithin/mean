var date = require('./date2');
console.log(date.myDateTime());